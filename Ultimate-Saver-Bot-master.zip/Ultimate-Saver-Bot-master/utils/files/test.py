# from download_spotify import DownloadMusic
# from spotify import SearchFromSpotify
# import json, time
# start = time.time()
# music_name = "Qaytma"
# music = SearchFromSpotify(track_name=music_name, limit=5)
# if music is not None:
#     urls = DownloadMusic(music)
# print(json.dumps(urls,indent=4, ensure_ascii=False))
# end = time.time()
# print(end-start)
